<!-- https://artisansweb.net/create-custom-search-form-wordpress/ -->

<!-- <form id="searchform" method="get" action="<?php echo esc_url(home_url('/')); ?>">
    <input type="text" class="search-field" name="s" placeholder="Search" value="<?php echo get_search_query(); ?>" /> -->
<!-- <input type="hidden" name="post_type[]" value="book" />
    <input type="hidden" name="post_type[]" value="magazine" />
    <input type="hidden" name="post_type[]" value="ebook" />
    <input type="hidden" name="post_type[]" value="pdf" /> -->
<!-- <input type="submit" value="Search" />
</form> -->

<!-- https://searchwp.com/v3/docs/kb/customize-search-form-selectively-modify-engine-weights/ -->
<!-- <form role="search" method="get" class="search-form" action="<?php echo home_url('/'); ?>">
    <label>
        <span class="screen-reader-text"><?php echo _x('Search for:', 'label') ?></span>
        <input type="search" class="search-field" placeholder="<?php echo esc_attr_x('Search …', 'placeholder') ?>" value="<?php echo get_search_query() ?>" name="s" title="<?php echo esc_attr_x('Search for:', 'label') ?>" />
    </label>
    <input type="submit" class="search-submit" value="<?php echo esc_attr_x('Search', 'submit button') ?>" />
</form> -->